package com.verityandroid;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

public class VerityModel<T extends VerityEntity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation(VerityAndroid.MODID, "verity"), "main");
    private final ModelPart root;
    public VerityModel(ModelPart root) { this.root = root; }
    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition part = mesh.getRoot();
        part.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-8, -8, -8, 16, 16, 16, new CubeDeformation(0.1F)), PartPose.ZERO);
        return LayerDefinition.create(mesh, 32, 32);
    }
    @Override public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) { root.yRot = ageInTicks * 0.025F; }
@Override
public void renderToBuffer(
        com.mojang.blaze3d.vertex.PoseStack poseStack,
        com.mojang.blaze3d.vertex.VertexConsumer vertexConsumer,
        int packedLight,
        int packedOverlay,
        float red,
        float green,
        float blue,
        float alpha) {
    root.render(poseStack, vertexConsumer, packedLight, packedOverlay,
            red, green, blue, alpha);
}
