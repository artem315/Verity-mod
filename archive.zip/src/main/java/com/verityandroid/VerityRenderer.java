package com.verityandroid;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

public class VerityRenderer extends EntityRenderer<VerityEntity> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(VerityAndroid.MODID, "textures/entity/verity.png");
    private final VerityModel<VerityEntity> model;
    public VerityRenderer(EntityRendererProvider.Context context) { super(context); model = new VerityModel<>(context.bakeLayer(VerityModel.LAYER_LOCATION)); shadowRadius = 0.0F; }
    @Override public void render(VerityEntity entity, float yaw, float partialTick, PoseStack pose, MultiBufferSource buffers, int light) {
        pose.pushPose(); pose.translate(0.0D, 0.15D, 0.0D); pose.scale(0.55F, 0.55F, 0.55F);
        model.setupAnim(entity, 0, 0, entity.tickCount + partialTick, 0, 0);
        model.renderToBuffer(pose, buffers.getBuffer(model.renderType(TEXTURE)), 0xF000F0, OverlayTexture.NO_OVERLAY, 1F, 1F, 1F, 1F);
        pose.popPose(); super.render(entity, yaw, partialTick, pose, buffers, light);
    }
    @Override public ResourceLocation getTextureLocation(VerityEntity entity) { return TEXTURE; }
}
