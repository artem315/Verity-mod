package com.verityandroid;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(VerityAndroid.MODID)
public class VerityAndroid {
    public static final String MODID = "verityandroid";
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final RegistryObject<EntityType<VerityEntity>> VERITY = ENTITIES.register("verity", () -> EntityType.Builder.of(VerityEntity::new, MobCategory.CREATURE).sized(0.7F, 0.7F).clientTrackingRange(8).updateInterval(20).build("verity"));

    public VerityAndroid(IEventBus bus) { ENTITIES.register(bus); }
}
